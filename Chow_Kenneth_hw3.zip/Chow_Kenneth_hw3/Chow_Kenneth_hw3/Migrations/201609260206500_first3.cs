namespace Chow_Kenneth_hw3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class first3 : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
